openssl req -x509 -new -nodes -keyout key.pem -out cert.pem -days 365 -config "san.cnf"
openssl x509 -outform der -in cert.pem -out server.crt
copy /b key.pem+cert.pem server.pem